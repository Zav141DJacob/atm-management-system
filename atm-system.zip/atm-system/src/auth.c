#include <termios.h>
#include "header.h"

char *USERS = "./data/users.txt";

void loginMenu(char a[50], char pass[50])
{
    struct termios oflags, nflags;

    system("clear");
    printf("\n\n\n\t\t\t\t   Bank Management System\n\t\t\t\t\t User Login:");
    scanf("%s", a);

    // disabling echo
    tcgetattr(fileno(stdin), &oflags);
    nflags = oflags;
    nflags.c_lflag &= ~ECHO;
    nflags.c_lflag |= ECHONL;

    if (tcsetattr(fileno(stdin), TCSANOW, &nflags) != 0)
    {
        perror("tcsetattr");
        return exit(1);
    }
    printf("\n\n\n\n\n\t\t\t\tEnter the password to login:");
    scanf("%s", pass);

    // restore terminal
    if (tcsetattr(fileno(stdin), TCSANOW, &oflags) != 0)
    {
        perror("tcsetattr");
        return exit(1);
    }
};

const char *getPassword(struct User u)
{
    FILE *fp;
    struct User userChecker;

    if ((fp = fopen(USERS, "r")) == NULL)
    {
        printf("Error! opening file");
        exit(1);
    }

    while (fscanf(fp, "%s %s", userChecker.name, userChecker.password) != EOF)
    {
        if (strcmp(userChecker.name, u.name) == 0)
        {
            fclose(fp);
            char *buff = userChecker.password;
            return buff;
        }
    }

    fclose(fp);
    return "no user found";
}

void registerMenu(struct User u)
{
    int option;
    struct termios oflags, nflags;
    
    FILE *fp;
    if ((fp = fopen(USERS, "a+")) == NULL)
    {
        printf("Error! opening file");
        exit(1);
    }
    char a[50];
    char pass[50];
    struct User userChecker;
    // char names[][50]
    // struct User u = a, pass;
    int isTaken = 0;
    
    system("clear");
    printf("\n\n\n\n\n\t\t\tEnter a new username or press '1' to go back: ");

    while(isTaken == 0)
    {
        FILE *rfp;
        if ((rfp = fopen(USERS, "r")) == NULL)
        {
            printf("Error! opening file");
            exit(1);
        }
        scanf("%s", a);
        if (strcmp(a, "1") == 0) {
            initMenu(&u);
            mainMenu(u);
            exit(1);
        }
        isTaken = 1;
        while (fscanf(rfp, "%s %s", userChecker.name, userChecker.password) != EOF)
        {

            if (strcmp(userChecker.name, a) == 0)
            {
                system("clear");
                printf("\n\n\n\n\n\t\tUsername already taken. Enter a new username or press '1' to go back:");
                isTaken = 0;
                break;
            }
        }
        memset(userChecker.name , 0, sizeof userChecker.name);
        memset(userChecker.password , 0, sizeof userChecker.password);
        fclose(rfp);
    }


    tcgetattr(fileno(stdin), &oflags);
    nflags = oflags;
    nflags.c_lflag &= ~ECHO;
    nflags.c_lflag |= ECHONL;

    if (tcsetattr(fileno(stdin), TCSANOW, &nflags) != 0)
    {
        perror("tcsetattr");
        return exit(1);
    }
    
    printf("\n\t\t\tEnter the password or press '1' to go back: ");
    scanf("%s", pass);


    if (tcsetattr(fileno(stdin), TCSANOW, &oflags) != 0)
    {
        perror("tcsetattr");
        return exit(1);
    }

    // printf("%s ", pass);
    // printf("%ld", strlen(pass));
    while (strlen(pass) < 4)
    {

        system("clear");
        printf("\n\n\n\n\n\t\tPassword must be more than 3 characters long!");
        printf("\n\t\tEnter a new password or press '1' to go back: ");
        scanf("%s", pass);
        if (strcmp(pass, "1") == 0)
        {
            initMenu(&u);
            mainMenu(u);
        }
    }



    fprintf(fp, "%s %s\n", a, pass);
    // fclose(rfp);
    fclose(fp);
    printf("\n✔ Success!\n\n");
    printf("\nEnter 1 to go back or 0 to exit:");
    scanf("%d", &option);
    if (option == 1)
    {
        initMenu(&u);
        mainMenu(u);
        exit(1);
    }
    else 
    {
        system("clear");
        exit(1);
    }    
}