#include "header.h"

const char *RECORDS = "./data/records.txt";

int getAccountFromFile(FILE *ptr, char name[50], struct Record *r)
{
    return fscanf(ptr, "%s %d %d/%d/%d %s %d %lf %s",
                  name,
                  &r->accountNbr,
                  &r->deposit.month,
                  &r->deposit.day,
                  &r->deposit.year,
                  r->country,
                  &r->phone,
                  &r->amount,
                  r->accountType) != EOF;
}

void saveAccountToFile(FILE *ptr, char name[50], struct Record r)
{
    fprintf(ptr, "%s %d %d/%d/%d %s %d %.2lf %s\n\n",
            name,
            r.accountNbr,
            r.deposit.month,
            r.deposit.day,
            r.deposit.year,
            r.country,
            r.phone,
            r.amount,
            r.accountType);
}

void replaceInFile(struct User u, int accountNum, struct Record rReplace, int shouldDelete, char replaceName[100])
{
    struct Record r;
    struct Record cr;
    char userName[100];

    FILE *pf = fopen(RECORDS, "r");
    FILE *tempF = fopen("./data/temprecords.txt", "a+");
    // printf("im here!");
    
    while (getAccountFromFile(pf, userName, &r))
    {
        if (strcmp(userName, u.name) == 0 && accountNum == r.accountNbr)
        {
            if (shouldDelete == 0)
            {
                continue;
            }
            saveAccountToFile(tempF, replaceName, rReplace);
        }
        else
        {
            saveAccountToFile(tempF, userName, r);
        }
    }
    
    fclose(pf);
    remove(RECORDS);
    fclose(tempF);
    FILE *newTempPf = fopen("./data/temprecords.txt", "r");
    FILE *newPf = fopen(RECORDS, "w");
    while (getAccountFromFile(tempF, userName, &cr))
    {
        saveAccountToFile(newPf, userName, cr);
    }
    fclose(newPf);
    fclose(newTempPf);
    remove("./data/temprecords.txt");
}

void stayOrReturn(int notGood, void f(struct User u), struct User u)
{
    int option;
    if (notGood == 0)
    {
        system("clear");
        printf("\n✖ Record not found!!\n");
    invalid:
        printf("\nEnter 0 to try again, 1 to return to main menu and 2 to exit:");
        scanf("%d", &option);
        if (option == 0)
            f(u);
        else if (option == 1)
            mainMenu(u);
        else if (option == 2)
            exit(0);
        else
        {
            printf("\nInsert a valid operation!\n");
            goto invalid;
        }
    }
    else
    {
        printf("\nEnter 1 to go to the main menu and 0 to exit:");
        scanf("%d", &option);
    }
    if (option == 1)
    {
        system("clear");
        mainMenu(u);
    }
    else
    {
        system("clear");
        exit(1);
    }
}

void success(struct User u)
{
    int option;
    printf("\n✔ Success!\n\n");
invalid:
    printf("Enter 1 to go to the main menu and 0 to exit!\n");
    scanf("%d", &option);
    system("clear");
    if (option == 1)
    {
        mainMenu(u);
    }
    else if (option == 0)
    {
        exit(1);
    }
    else
    {
        printf("Insert a valid operation!\n");
        goto invalid;
    }
}

void createNewAcc(struct User u)
{
    struct Record r;
    struct Record cr;
    char userName[50];
    FILE *pf = fopen(RECORDS, "a+");

    system("clear");
    printf("\t\t\t===== New record =====\n");

    printf("\nEnter today's date(mm/dd/yyyy):");
    scanf("%d/%d/%d", &r.deposit.month, &r.deposit.day, &r.deposit.year);
    while (r.deposit.month <= 0 || r.deposit.day <= 0 || r.deposit.year <= 0)
    {
        printf("\nPlease enter today's date in the correct format(mm/dd/yyyy):");
        scanf("%d/%d/%d", &r.deposit.month, &r.deposit.day, &r.deposit.year);
    }
    printf("\nEnter the account number:");
    scanf("%d", &r.accountNbr);

    while (getAccountFromFile(pf, userName, &cr))
    {
        if (strcmp(userName, u.name) == 0 && cr.accountNbr == r.accountNbr)
        {
            printf("\n✖ This Account already exists for this user\n\n");
            stayOrReturn(1, createNewAcc, u);
        }
    }
    
    printf("\nEnter the country:");
    scanf("%s", r.country);
    printf("\nEnter the phone number:");
    scanf("%d", &r.phone);
    printf("\nEnter amount to deposit: $");
    scanf("%lf", &r.amount);
    printf("\nChoose the type of account:\n\t-> saving\n\t-> current\n\t-> fixed01(for 1 year)\n\t-> fixed02(for 2 years)\n\t-> fixed03(for 3 years)\n\n\tEnter your choice:");
    scanf("%s", r.accountType);

    saveAccountToFile(pf, u.name, r);

    fclose(pf);
    success(u);
}

void checkAllAccounts(struct User u)
{
    char userName[100];
    struct Record r;

    FILE *pf = fopen(RECORDS, "r");

    system("clear");
    printf("\t\t====== All accounts from user, %s =====\n\n", u.name);
    while (getAccountFromFile(pf, userName, &r))
    {
        if (strcmp(userName, u.name) == 0)
        {
            printf("_____________________\n");
            printf("\nAccount number:%d\nDeposit Date:%d/%d/%d \ncountry:%s \nPhone number:%d \nAmount deposited: $%.2f \nType Of Account:%s\n",
                   r.accountNbr,
                   r.deposit.day,
                   r.deposit.month,
                   r.deposit.year,
                   r.country,
                   r.phone,
                   r.amount,
                   r.accountType);
        }
    }
    fclose(pf);
    success(u);
}
void updateAccInfo(struct User u)
{
    int accountNum, infoUpdate;
    struct Record r;
    char userName[100];
    int found = 1;

    FILE *pf = fopen(RECORDS, "r");
    // printf("%s", r);
    printf("What is the account number that you want to change: ");
    scanf("%d", &accountNum);
    printf("\n");
    

    while (getAccountFromFile(pf, userName, &r))
    {
        if (strcmp(userName, u.name) == 0)
        {
            if (accountNum == r.accountNbr)
            {
                found = 0;
                printf("Which information do you want to update?\n1 -> Phone number\n2 -> Country\n\n");
                scanf("%d", &infoUpdate);
                switch (infoUpdate)
                {
                case 1:
                    printf("Enter the new phone number: ");
                    int newNum;
                    scanf("%d", &newNum);
                    r.phone = newNum;
                    replaceInFile(u, accountNum, r, 1, userName);
                    break;
                case 2:
                    printf("Enter your new Country: ");
                    char newCountry[100];
                    scanf("%s", newCountry);
                    // r.country = newCountry;
                    memset(r.country, 0, sizeof r.country);
                    strcpy(r.country, newCountry);
                    replaceInFile(u, accountNum, r, 1, userName);
                    break;
                }
                break;
            }
        }
    }
    fclose(pf);
    if (found == 0)
    {
        success(u);
    }
    else
    {
        stayOrReturn(0, updateAccInfo, u);
    }
    
}

void checkAcc(struct User u)
{
    int accountNum;
    struct Record r;
    char userName[100];
    int found = 1;
    FILE *pf = fopen(RECORDS, "r");

    printf("\nEnter the account number: ");
    scanf("%d", &accountNum);

    while (getAccountFromFile(pf, userName, &r))
    {
        if (strcmp(userName, u.name) == 0)
        {
            if (accountNum == r.accountNbr)
            {
                found = 0;
                printf("\nAccount number:%d\nDeposit Date:%d/%d/%d \ncountry:%s \nPhone number:%d \nAmount deposited: $%.2f \nType Of Account:%s\n",
                   r.accountNbr,
                   r.deposit.day,
                   r.deposit.month,
                   r.deposit.year,
                   r.country,
                   r.phone,
                   r.amount,
                   r.accountType);

                if (strcmp(r.accountType, "current") == 0)
                {
                    printf("You will not get interests because the account is of type current\n");
                }
                else if (strcmp(r.accountType, "fixed01") == 0)
                {
                    printf("You will get $%.2lf as interest on day %d/%d/%d\n", (double)r.amount * 0.04, r.deposit.day, r.deposit.month, r.deposit.year + 1);
                }
                else if (strcmp(r.accountType, "fixed02") == 0)
                {
                    printf("You will get $%.2lf as interest on %d/%d/%d\n", (double)r.amount * 0.05 * 2, r.deposit.day, r.deposit.month, r.deposit.year + 2);
                }
                else if (strcmp(r.accountType, "fixed03") == 0)
                {
                    printf("You will get $%.2lf as interest on day %d/%d/%d\n", (double)r.amount * 0.08 * 3, r.deposit.day, r.deposit.month, r.deposit.year + 3);
                }
                else if (strcmp(r.accountType, "saving") == 0)
                {
                    printf("You will get $%.2lf as interest on day %d of every month\n", (double)r.amount * 0.07 / 12, r.deposit.day);
                }
            }
        }
    }
    fclose(pf);
    if (found == 0)
    {
        success(u);
    }
    else
    {
        stayOrReturn(0, checkAcc, u);
    }
}

void makeTransaction(struct User u)
{
    int accountNum, transaction;
    double amountToDo;
    struct Record r;
    int found = 1;
    char userName[100];

    FILE *pf = fopen(RECORDS, "r");
    printf("\nEnter account number of the customer: ");
    scanf("%d", &accountNum);

    while (getAccountFromFile(pf, userName, &r))
    {
        if (strcmp(userName, u.name) == 0)
        {
            if (accountNum == r.accountNbr)
            {
                found = 0;
                // I thought this was needed, just uncomment this 
                // for it to not be able to transact with fixed accounts :)
                // if (strcmp(r.accountType, "savings") != 0 && strcmp(r.accountType, "current") != 0) 
                // {
                //     printf("You can not deposit or withdraw cash in fixed accounts!\n");
                //     stayOrReturn(1, makeTransaction, u);
                //     mainMenu(u);
                // }
                printf("\nDo you want to:\n     1 -> Withdraw\n     2 -> Deposit\n");
                scanf("%d", &transaction);
                switch (transaction) 
                {
                    case 1:
                        printf("Enter the amount you want to withdraw: $");
                        scanf("%lf", &amountToDo);
                        if (amountToDo > r.amount)
                        {
                            printf("\nThat account doesnt have enough money for the withdrawal!\n");
                            stayOrReturn(1, makeTransaction, u);
                        } 
                        else 
                        {
                            r.amount -= amountToDo;
                            replaceInFile(u, accountNum, r, 1, userName);
                        }
                        break;
                    case 2:
                        printf("Enter the amount you want to deposit: $");
                        scanf("%lf", &amountToDo);
                        r.amount += amountToDo;
                        replaceInFile(u, accountNum, r, 1, userName);
                        break;
                }
                break;
            }
        }
    }
    fclose(pf);
    if (found == 0)
    {
        success(u);
    }
    else
    {
        stayOrReturn(0, makeTransaction, u);
    }
}

void delAcc(struct User u)
{
    int accountNum;
    struct Record r;
    int found = 1;
    char userName[100];

    FILE *pf = fopen(RECORDS, "r");
    printf("\nEnter account number of the customer: ");
    scanf("%d", &accountNum);

    while (getAccountFromFile(pf, userName, &r))
    {
        if (strcmp(userName, u.name) == 0)
        {
            if (accountNum == r.accountNbr)
            {
                found = 0;
                replaceInFile(u, accountNum, r, 0, userName);
                break;
            }
        }
    }
    fclose(pf);
    if (found == 0)
    {
        success(u);
    }
    else
    {
        stayOrReturn(0, delAcc, u);
    }
}

void transferOwner(struct User u)
{
    int accountNum;
    struct Record r;
    char userName[100];
    char newUser[100];
    int found = 1;

    FILE *pf = fopen(RECORDS, "r");
    printf("\nEnter account number you want to transfer ownership: ");
    scanf("%d", &accountNum);

    while (getAccountFromFile(pf, userName, &r))
    {
        if (strcmp(userName, u.name) == 0)
        {
            if (accountNum == r.accountNbr)
            {
                found = 0;
                printf("         =====Account to transfer=====\n");
                printf("\nAccount number:%d\nDeposit Date:%d/%d/%d \ncountry:%s \nPhone number:%d \nAmount deposited: $%.2f \nType Of Account:%s\n",
                   r.accountNbr,
                   r.deposit.day,
                   r.deposit.month,
                   r.deposit.year,
                   r.country,
                   r.phone,
                   r.amount,
                   r.accountType);
                printf("\nWhich user would you want to transfer the ownership to: ");
                scanf("%s", newUser);
                replaceInFile(u, accountNum, r, 1, newUser);
            }
        }
    }
    fclose(pf);
    if (found == 0)
    {
        success(u);
    }
    else
    {
        stayOrReturn(0, transferOwner, u);
    }
}



